<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Atlas-Props-sheet1" tilewidth="32" tileheight="32" tilecount="3520" columns="44">
 <image source="../../Props/Static props/Atlas-Props-sheet1.png" width="1408" height="2560"/>
</tileset>
