<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Beach-transition tiles between coast platform(grass2) and beach" tilewidth="32" tileheight="32" tilecount="260" columns="20">
 <image source="../../Tilesets/Beach/Beach-transition tiles between coast platform and beach-spritesheet.png" width="640" height="416"/>
 <tile id="21">
  <animation>
   <frame tileid="21" duration="100"/>
   <frame tileid="24" duration="100"/>
   <frame tileid="25" duration="100"/>
   <frame tileid="26" duration="100"/>
   <frame tileid="27" duration="100"/>
   <frame tileid="28" duration="100"/>
   <frame tileid="29" duration="100"/>
   <frame tileid="30" duration="100"/>
   <frame tileid="31" duration="100"/>
   <frame tileid="32" duration="100"/>
   <frame tileid="33" duration="100"/>
   <frame tileid="34" duration="100"/>
   <frame tileid="35" duration="100"/>
   <frame tileid="36" duration="100"/>
   <frame tileid="37" duration="100"/>
   <frame tileid="38" duration="100"/>
  </animation>
 </tile>
 <tile id="22">
  <animation>
   <frame tileid="22" duration="100"/>
   <frame tileid="44" duration="100"/>
   <frame tileid="45" duration="100"/>
   <frame tileid="46" duration="100"/>
   <frame tileid="47" duration="100"/>
   <frame tileid="48" duration="100"/>
   <frame tileid="49" duration="100"/>
   <frame tileid="50" duration="100"/>
   <frame tileid="51" duration="100"/>
   <frame tileid="52" duration="100"/>
   <frame tileid="53" duration="100"/>
   <frame tileid="54" duration="100"/>
   <frame tileid="55" duration="100"/>
   <frame tileid="56" duration="100"/>
   <frame tileid="57" duration="100"/>
   <frame tileid="58" duration="100"/>
  </animation>
 </tile>
 <tile id="81">
  <animation>
   <frame tileid="81" duration="100"/>
   <frame tileid="84" duration="100"/>
   <frame tileid="85" duration="100"/>
   <frame tileid="86" duration="100"/>
   <frame tileid="87" duration="100"/>
   <frame tileid="88" duration="100"/>
   <frame tileid="89" duration="100"/>
   <frame tileid="90" duration="100"/>
   <frame tileid="91" duration="100"/>
   <frame tileid="92" duration="100"/>
   <frame tileid="93" duration="100"/>
   <frame tileid="94" duration="100"/>
   <frame tileid="95" duration="100"/>
   <frame tileid="96" duration="100"/>
   <frame tileid="97" duration="100"/>
   <frame tileid="98" duration="100"/>
  </animation>
 </tile>
 <tile id="82">
  <animation>
   <frame tileid="82" duration="100"/>
   <frame tileid="104" duration="100"/>
   <frame tileid="105" duration="100"/>
   <frame tileid="106" duration="100"/>
   <frame tileid="107" duration="100"/>
   <frame tileid="108" duration="100"/>
   <frame tileid="109" duration="100"/>
   <frame tileid="110" duration="100"/>
   <frame tileid="111" duration="100"/>
   <frame tileid="112" duration="100"/>
   <frame tileid="113" duration="100"/>
   <frame tileid="114" duration="100"/>
   <frame tileid="115" duration="100"/>
   <frame tileid="116" duration="100"/>
   <frame tileid="117" duration="100"/>
   <frame tileid="118" duration="100"/>
  </animation>
 </tile>
 <tile id="141">
  <animation>
   <frame tileid="141" duration="100"/>
   <frame tileid="144" duration="100"/>
   <frame tileid="145" duration="100"/>
   <frame tileid="146" duration="100"/>
   <frame tileid="147" duration="100"/>
   <frame tileid="148" duration="100"/>
   <frame tileid="149" duration="100"/>
   <frame tileid="150" duration="100"/>
   <frame tileid="151" duration="100"/>
   <frame tileid="152" duration="100"/>
   <frame tileid="153" duration="100"/>
   <frame tileid="154" duration="100"/>
   <frame tileid="155" duration="100"/>
   <frame tileid="156" duration="100"/>
   <frame tileid="157" duration="100"/>
   <frame tileid="158" duration="100"/>
  </animation>
 </tile>
 <tile id="161">
  <animation>
   <frame tileid="161" duration="100"/>
   <frame tileid="164" duration="100"/>
   <frame tileid="165" duration="100"/>
   <frame tileid="166" duration="100"/>
   <frame tileid="167" duration="100"/>
   <frame tileid="168" duration="100"/>
   <frame tileid="169" duration="100"/>
   <frame tileid="170" duration="100"/>
   <frame tileid="171" duration="100"/>
   <frame tileid="172" duration="100"/>
   <frame tileid="173" duration="100"/>
   <frame tileid="174" duration="100"/>
   <frame tileid="175" duration="100"/>
   <frame tileid="176" duration="100"/>
   <frame tileid="177" duration="100"/>
   <frame tileid="178" duration="100"/>
  </animation>
 </tile>
 <tile id="201">
  <animation>
   <frame tileid="201" duration="100"/>
   <frame tileid="204" duration="100"/>
   <frame tileid="205" duration="100"/>
   <frame tileid="206" duration="100"/>
   <frame tileid="207" duration="100"/>
   <frame tileid="208" duration="100"/>
   <frame tileid="209" duration="100"/>
   <frame tileid="210" duration="100"/>
   <frame tileid="211" duration="100"/>
   <frame tileid="212" duration="100"/>
   <frame tileid="213" duration="100"/>
   <frame tileid="214" duration="100"/>
   <frame tileid="215" duration="100"/>
   <frame tileid="216" duration="100"/>
   <frame tileid="217" duration="100"/>
   <frame tileid="218" duration="100"/>
  </animation>
 </tile>
 <tile id="221">
  <animation>
   <frame tileid="221" duration="100"/>
   <frame tileid="224" duration="100"/>
   <frame tileid="225" duration="100"/>
   <frame tileid="226" duration="100"/>
   <frame tileid="227" duration="100"/>
   <frame tileid="228" duration="100"/>
   <frame tileid="229" duration="100"/>
   <frame tileid="230" duration="100"/>
   <frame tileid="231" duration="100"/>
   <frame tileid="232" duration="100"/>
   <frame tileid="233" duration="100"/>
   <frame tileid="234" duration="100"/>
   <frame tileid="235" duration="100"/>
   <frame tileid="236" duration="100"/>
   <frame tileid="237" duration="100"/>
   <frame tileid="238" duration="100"/>
  </animation>
 </tile>
</tileset>
